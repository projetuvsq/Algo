#############################
SERHAN Wissam et PITTIS Thomas
#############################

Pour compiler :
	make compile

Pour executer :
	make run

Pour faire le ménage :
	make clean

pour Nettoyer puis Compiler et Executer :
	make exec
